#!/bin/bash

# FTPS Deployment Script for Azure
# Uses the FTPS credentials provided

echo "🚀 Starting FTPS deployment to Azure..."

# FTPS Configuration
FTP_HOST="waws-prod-yt1-107.ftp.azurewebsites.windows.net"
FTP_USER="PIMS-blue-bombers-stats\$PIMS-blue-bombers-stats"
FTP_PASS="uj0fGXh3Hvi3WESvqoc0xzegaNjuhCXqifgDjMNiYHx6ppiFgbY619lhbN7b"
FTP_PATH="/site/wwwroot"

# Check if curl is available
if ! command -v curl &> /dev/null; then
    echo "❌ curl is not installed. Please install curl first."
    exit 1
fi

# Create a temporary directory for deployment files
TEMP_DIR="deploy-temp"
mkdir -p $TEMP_DIR

# Copy files to temp directory (excluding node_modules and output)
echo "📦 Preparing files for deployment..."
cp -r *.js *.json *.html *.md *.sh *.xml $TEMP_DIR/ 2>/dev/null || true
cp -r .gitignore $TEMP_DIR/ 2>/dev/null || true

# Create package.json if it doesn't exist
if [ ! -f "$TEMP_DIR/package.json" ]; then
    echo "Creating package.json..."
    cat > $TEMP_DIR/package.json << 'EOF'
{
  "name": "blue-bombers-stats-automation",
  "version": "1.0.0",
  "description": "Automated Blue Bombers 2025 season stats fetcher",
  "main": "server.js",
  "scripts": {
    "fetch": "node automated-fetch.js",
    "server": "node server.js",
    "start": "node server.js",
    "test": "node automated-fetch.js"
  },
  "dependencies": {
    "node-fetch": "^3.3.2"
  },
  "type": "module",
  "engines": {
    "node": ">=18.0.0"
  },
  "keywords": [
    "cfl",
    "blue-bombers",
    "stats",
    "automation"
  ],
  "author": "Your Name",
  "license": "MIT"
}
EOF
fi

# Upload files using curl
echo "📤 Uploading files to Azure..."

# Function to upload a file
upload_file() {
    local file="$1"
    local remote_path="$2"
    
    echo "Uploading: $file"
    curl -T "$file" \
         --ftp-create-dirs \
         --user "$FTP_USER:$FTP_PASS" \
         "ftps://$FTP_HOST$FTP_PATH/$remote_path" \
         --ftp-ssl \
         --silent \
         --show-error
    
    if [ $? -eq 0 ]; then
        echo "✅ Successfully uploaded: $file"
    else
        echo "❌ Failed to upload: $file"
    fi
}

# Upload main files
for file in $TEMP_DIR/*; do
    if [ -f "$file" ]; then
        filename=$(basename "$file")
        upload_file "$file" "$filename"
    fi
done

# Clean up
echo "🧹 Cleaning up temporary files..."
rm -rf $TEMP_DIR

echo "✅ FTPS deployment completed!"
echo ""
echo "🌐 Your app should be available at:"
echo "   https://pims-blue-bombers-stats.azurewebsites.net/"
echo ""
echo "📊 Stats files will be available at:"
echo "   https://pims-blue-bombers-stats.azurewebsites.net/stats/"
echo ""
echo "⚠️  Note: You may need to wait a few minutes for the changes to take effect." 